package marsRover;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class marsRoverTest {

	@Test public void checkInitialPositionandDirection() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new North();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
		
		assertEquals(initialDirection,rover.getDirection());
		assertEquals(initialPosition, rover.getPosition());
	}

	
	@Test public void moveFowardN() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new North();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
		rover.executeCommand("f");
		    
		Point expectedPosition = new Point(1, 2);
		assertEquals(expectedPosition, rover.getPosition());
		}
	
	@Test public void moveBackwardsN() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new North();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("b");
	    
	    Point expectedPosition = new Point(1, 0);
	    assertEquals(expectedPosition, rover.getPosition());	
	}

	
	@Test public void rotateLeftN() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new North();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("l");
	    
	    Move expectedDirection = new West();
	    assertEquals(rover.getDirection(), expectedDirection);	
	}
	
	@Test public void rotateRightN() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new North();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("r");
	    
	    Move expectedDirection = new East();
	    assertEquals(rover.getDirection(), expectedDirection);
	}

	
	@Test public void moveFowardS() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new South();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("f");
	    
	    Point expectedPosition = new Point(1, 0);
	    assertEquals(expectedPosition, rover.getPosition());
	}
		
	@Test public void moveBackwardsS() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new South();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("b");
	    
	    Point expectedPosition = new Point(1, 2);
	    assertEquals(expectedPosition, rover.getPosition());	
	}
	
	@Test public void rotateLeftS() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new South();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("l");
	    
	    Move expectedDirection = new East();
	    assertEquals(rover.getDirection(), expectedDirection);;
	}
	
	@Test public void rotateRightS() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new South();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("r");
	    
	    Move expectedDirection = new West();
	    assertEquals(rover.getDirection(), expectedDirection);
	}
	
	@Test public void movefowardW() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new West();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
		rover.executeCommand("f");
		    
		Point expectedPosition = new Point(0, 1);
	    assertEquals(expectedPosition, rover.getPosition());
	}
	
	@Test public void moveBackwardsW() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new West();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
		rover.executeCommand("b");
		    
		Point expectedPosition = new Point(2, 1);
		assertEquals(expectedPosition, rover.getPosition());
	}
	
	@Test public void rotateLeftW() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new West();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("l");
	    
	    Move expectedDirection = new South();
	    assertEquals(rover.getDirection(), expectedDirection);;
	}
	
	@Test public void rotateRightW() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new West();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("r");
	    
	    Move expectedDirection = new North();
	    assertEquals(rover.getDirection(), expectedDirection);;
	}
	
	@Test public void movefowardE() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new East();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
		rover.executeCommand("f");
		    
		Point expectedPosition = new Point(2, 1);
		assertEquals(expectedPosition, rover.getPosition());
	}
	
	@Test public void moveBackwardsE() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new East();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
		rover.executeCommand("b");
		    
		Point expectedPosition = new Point(0, 1);
		assertEquals(expectedPosition, rover.getPosition());
	}
	
	@Test public void rotateLeftE() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new East();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
		rover.executeCommand("l");
    
		Move expectedDirection = new North();
	    assertEquals(rover.getDirection(), expectedDirection);;
	}
	
	@Test public void rotateRightE() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new East();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("r");
	    
	    Move expectedDirection = new South();
	    assertEquals(rover.getDirection(), expectedDirection);;
	}
	
	
	@Test public void moveinmanydirections() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new North();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("fl");
	    
	    Point expectedPoint = new Point(1,2);
	    Move expectedDirection = new West();
	    assertEquals(rover.getPosition(), expectedPoint);
	    assertEquals(rover.getDirection(), expectedDirection);
	}	
	
	@Test public void DoubleRotationRight() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new North();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("rr");
	   
	    Move expectedDirection = new South();
	    assertEquals(rover.getDirection(), expectedDirection);;
	}
	
	@Test public void DoubleRotationLeft() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new East();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("ll");
	   
	    Move expectedDirection = new West();
	    assertEquals(rover.getDirection(), expectedDirection);;
	}
	
	@Test public void WholeRotation() {
		Point initialPosition = new Point(0,0);
		Move initialDirection = new East();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("llll");
	   
	    Move expectedDirection = new East();
	    assertEquals(rover.getDirection(), expectedDirection);;
	}
	
	@Test public void WholeRotation2() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new East();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("rrrr");
	   
	    Move expectedDirection = new East();
	    assertEquals(rover.getDirection(), expectedDirection);;
	}
	
	@Test public void RotationtoOneSideAndRotateBack() {
		Point initialPosition = new Point(1,1);
		Move initialDirection =new East();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("rrll");
	   
	    Move expectedDirection = new East();
	    assertEquals(rover.getDirection(), expectedDirection);;
	}
	
	
	@Test public void MoveAndRotate() {
		Point initialPosition = new Point(1,1);
		Move initialDirection = new South();
		MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("rrfrl");
	   
	    Move expectedDirection = new North();
	    assertEquals(rover.getDirection(), expectedDirection);;
	}
	
	
	

	@Test
	public void handleMultipleCommands() {
	    Point initialPosition = new Point(0, 0);
	    Move initialDirection = new North();
	    MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("ffrff");
	    
	    Point expectedPosition = new Point(2, 2);
	    assertEquals(expectedPosition, rover.getPosition());
	    Move expectedDirection = new East();
	    assertEquals(expectedDirection, rover.getDirection());
	    /////
	}

	@Test
	public void handleMultipleMovesInSameDirection() {
	    Point initialPosition = new Point(2, 2);
	    Move initialDirection = new South();
	    MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("ff");
	    
	    Point expectedPosition = new Point(2, 0);
	    assertEquals(expectedPosition, rover.getPosition());
	    Move expectedDirection = new South();
	    assertEquals(expectedDirection, rover.getDirection());
	}

	@Test
	public void handleMultipleRotationsInARow() {
	    Point initialPosition = new Point(2, 2);
	    Move initialDirection = new North();
	    MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("ll");
	    
	    Point expectedPosition = new Point(2, 2);
	    assertEquals(expectedPosition, rover.getPosition());
	    Move expectedDirection = new South();
	    assertEquals(expectedDirection, rover.getDirection());
	}
	
	@Test
	public void handleInvalidCommands() {
	    Point initialPosition = new Point(3, 4);
	    Move initialDirection = new East();
	    MarsRover rover = new MarsRover(initialPosition, initialDirection);
	   
	    assertThrows(IllegalArgumentException.class, () -> rover.executeCommand("p"));

	    Point expectedPosition = new Point(3, 4);
	    assertEquals(expectedPosition, rover.getPosition());
	    Move expectedDirection = new East();
	    assertEquals(expectedDirection, rover.getDirection());
	}

	@Test
	    public void HandleEmptyCommands() {
	        MarsRover marsRover = new MarsRover(new Point(0, 0), new North());
	        marsRover.executeCommand("");
	    }
	
	//CHEQUEAR//
	@Test
    public void testStopExecutionOnError() {
        MarsRover marsRover = new MarsRover(new Point(1, 0), new North());
        assertThrows(IllegalArgumentException.class, () -> marsRover.executeCommand("lfrz"));
        assertEquals(new North(), marsRover.getDirection());
        assertEquals(new Point(0, 0), marsRover.getPosition());
    }
	///// agregue mas a partir de aca//// 
	@Test
	public void handleInvalidCommandsIgnoringCase() {
	    Point initialPosition = new Point(0, 0);
	    Move initialDirection = new North();
	    MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    
	    // Testing lowercase and uppercase invalid commands
	    assertThrows(IllegalArgumentException.class, () -> rover.executeCommand("p"));
	    assertThrows(IllegalArgumentException.class, () -> rover.executeCommand("P"));
	}

	@Test
	public void handleMultipleMovesAndRotations() {
	    Point initialPosition = new Point(0, 0);
	    Move initialDirection = new North();
	    MarsRover rover = new MarsRover(initialPosition, initialDirection);
	    rover.executeCommand("ffrrbbll");
	    
	    Point expectedPosition = new Point(0, 4);
	    assertEquals(expectedPosition, rover.getPosition());
	    Move expectedDirection = new North();
	    assertEquals(expectedDirection, rover.getDirection());
	}

	@Test
	public void handleLargeNumberofCommands() {
	    Point initialPosition = new Point(0, 0);
	    Move initialDirection = new North();
	    MarsRover rover = new MarsRover(initialPosition, initialDirection);

	    StringBuilder commands = new StringBuilder();
	    for (int i = 0; i < 1000; i++) {
	        commands.append("f");
	    }
	    rover.executeCommand(commands.toString());

	    Point expectedPosition = new Point(0, 1000);
	    assertEquals(expectedPosition, rover.getPosition());
	}

	@Test
	public void handleCommandsWithUnknownInstructions() {
	    Point initialPosition = new Point(0, 0);
	    Move initialDirection = new North();
	    MarsRover rover = new MarsRover(initialPosition, initialDirection);

	    assertThrows(IllegalArgumentException.class, () -> rover.executeCommand("fxyzblm"));

	    Point expectedPosition = new Point(0, 1);
	    assertEquals(expectedPosition, rover.getPosition());
	    Move expectedDirection = new North();
	    assertEquals(expectedDirection, rover.getDirection());
	}

	@Test
	public void cantHandleCommandsWithSpaces() {
	    Point initialPosition = new Point(0, 0);
	    Move initialDirection = new North();
	    MarsRover rover = new MarsRover(initialPosition, initialDirection);

	    assertThrows(IllegalArgumentException.class, () -> rover.executeCommand("f r b l"));

	    Point expectedPosition = new Point(0, 1);
	    assertEquals(expectedPosition, rover.getPosition());
	    Move expectedDirection = new North();
	    assertEquals(expectedDirection, rover.getDirection());
	}

	
	@Test
	public void handleCommandsWithNumbers() {
	    Point initialPosition = new Point(0, 0);
	    Move initialDirection = new North();
	    MarsRover rover = new MarsRover(initialPosition, initialDirection);
 		
		assertThrows(IllegalArgumentException.class, () -> rover.executeCommand("fr32b1l4"));

	    Point expectedPosition = new Point(0, 1);
	    assertEquals(expectedPosition, rover.getPosition());
	    Move expectedDirection = new East();
	    assertEquals(expectedDirection, rover.getDirection());
	}  



	
//	@Test
//	public void handleInvalidInitialDirection() {
//	    // Invalid initial direction
//	    assertThrows(IllegalArgumentException.class, () -> new MarsRover(new Point(0, 0), null));
//	}
//	@Test
//	public void handleInvalidInitialPosition() {
//	    // Invalid initial position
//	    assertThrows(IllegalArgumentException.class, () -> new MarsRover(null, new North()));
//	}



}
 

